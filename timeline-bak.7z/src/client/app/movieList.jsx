import React from 'react'
import {render} from 'react-dom'

export class MovieItem extends React.Component{
    render(){
    	return (
        	<li className="clearfix ">
            	<div className="col-md-3">
            		<img src={this.props.src} width="150" title={this.props.title} />
            	</div>
            	<div className="col-md-9">
            		<h4>{this.props.title} <small>({this.props.rating})</small></h4>
            	</div>
            </li>
        )
    }
}

export default class MovieList extends React.Component {
	constructor(props){
		super(props);
		this.state = {
			movies: [],
			activeTheater: ''
		}
	}
	componentDidMount(){
		var movies = this.props.movies.map(function(movie){
	    	return { 
	        	id: movie.id, 
	        	rating: movie.rating, 
	        	src: movie.poster, 
	        	title: movie.title
	    	};
 	    });
 	    

		this.setState({ movies: movies });
	}
	render() {
		var movies = this.state.movies.map(function(movie, index){
			return <MovieItem key={index} ref={movie.id} src={movie.src} rating={movie.rating} title={movie.title} />
		});
		return (
			<ul>
				{movies}
			</ul>
		)
	}
}